import unittest

from core.text_utils import clean_page_text, find_doi, match_key, normalize


class TextUtilsTests(unittest.TestCase):
    def test_clean_page_text_removes_control_chars_and_extra_blank_lines(self):
        raw = "Hello\x00 world  \r\n\r\n\r\n\r\nNext\x0c line"
        self.assertEqual(clean_page_text(raw), "Hello world\n\nNext line")

    def test_normalize_handles_ligatures_quotes_and_hyphenation(self):
        self.assertEqual(normalize("The \ufb01rst \u201cresult\u201d was well-\nknown"),
                         'The first "result" was wellknown')

    def test_match_key_ignores_formatting(self):
        self.assertEqual(match_key("Well-known, \u201cfirst\u201d result!"), "wellknownfirstresult")

    def test_find_doi_strips_trailing_punctuation(self):
        self.assertEqual(find_doi("See doi:10.1000/xyz123."), "10.1000/xyz123")
        self.assertEqual(find_doi("(https://doi.org/10.1016/j.cell.2020.01.001)"),
                         "10.1016/j.cell.2020.01.001")

    def test_find_doi_returns_none_when_absent(self):
        self.assertIsNone(find_doi("No identifier here, just the number 10.5 and text."))


if __name__ == "__main__":
    unittest.main()
