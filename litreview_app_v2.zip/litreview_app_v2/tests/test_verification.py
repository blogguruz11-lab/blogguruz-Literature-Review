import unittest

from core.verification import NOT_FOUND, TOO_SHORT, VERIFIED, WRONG_PAGE, PageIndex

PAGES = {1: "The first result was well-known to the \u201cresearch\u201d community in 2019.",
         2: "Sample size was limited to forty participants overall in this trial."}


class VerificationTests(unittest.TestCase):
    def setUp(self):
        self.index = PageIndex(PAGES)

    def test_verified_on_cited_page(self):
        v = self.index.verify("Sample size was limited to forty participants", 2)
        self.assertEqual((v.status, v.found_on), (VERIFIED, (2,)))

    def test_formatting_differences_are_tolerated(self):
        v = self.index.verify('first result was well known to the "research" community', 1)
        self.assertEqual(v.status, VERIFIED)

    def test_wrong_page(self):
        v = self.index.verify("Sample size was limited to forty participants", 1)
        self.assertEqual((v.status, v.found_on), (WRONG_PAGE, (2,)))

    def test_not_found(self):
        v = self.index.verify("The treatment cured every patient in the study", 1)
        self.assertEqual(v.status, NOT_FOUND)

    def test_too_short(self):
        self.assertEqual(self.index.verify("well known", 1).status, TOO_SHORT)

    def test_page_that_was_never_sent_is_not_verified(self):
        v = self.index.verify("Sample size was limited to forty participants", 99)
        self.assertEqual(v.status, WRONG_PAGE)


if __name__ == "__main__":
    unittest.main()
