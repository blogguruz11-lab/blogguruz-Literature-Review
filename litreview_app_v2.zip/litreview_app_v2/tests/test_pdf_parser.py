import unittest

from core import errors
from core.pdf_parser import parse_pdf
from tests.pdf_factory import LONG, encrypt, make_pdf, with_page_labels


class ParsePDFTests(unittest.TestCase):
    def test_valid_pdf_keeps_page_order_and_text(self):
        data = make_pdf([f"Page one. {LONG}", f"Page two. {LONG}", f"Page three. {LONG}"])
        result = parse_pdf(data, "paper.pdf")
        self.assertEqual(result.page_count, 3)
        self.assertEqual([p.index for p in result.pages], [1, 2, 3])
        self.assertIn("Page two.", result.pages[1].text)
        self.assertNotIn("Page two.", result.pages[0].text)
        self.assertEqual(result.file_name, "paper.pdf")
        self.assertEqual(len(result.sha256), 64)
        self.assertGreater(result.word_count, 30)
        self.assertEqual(result.warnings, [])

    def test_no_labels_means_label_is_none(self):
        result = parse_pdf(make_pdf([LONG, LONG]))
        self.assertEqual([p.label for p in result.pages], [None, None])

    def test_printed_page_labels_are_read(self):
        data = with_page_labels(make_pdf([LONG, LONG, LONG, LONG]))
        result = parse_pdf(data)
        self.assertEqual([p.label for p in result.pages], ["i", "ii", "415", "416"])

    def test_doi_candidate_found_on_first_pages(self):
        result = parse_pdf(make_pdf([f"{LONG}\nDOI: 10.1234/abc.2021.001"]))
        self.assertEqual(result.doi_candidate, "10.1234/abc.2021.001")

    def test_blank_page_is_flagged_but_file_still_parses(self):
        result = parse_pdf(make_pdf([LONG, "", LONG]))
        self.assertEqual(result.low_text_pages, [2])
        self.assertEqual(len(result.warnings), 1)
        self.assertIn("2", result.warnings[0])

    def test_pdf_without_text_layer_raises_no_text(self):
        with self.assertRaises(errors.NoTextError):
            parse_pdf(make_pdf(["", "", ""]))

    def test_empty_file(self):
        with self.assertRaises(errors.EmptyFileError):
            parse_pdf(b"")

    def test_not_a_pdf(self):
        with self.assertRaises(errors.InvalidPDFError):
            parse_pdf(b"hello, this is plain text")

    def test_pdf_header_but_garbage_body(self):
        with self.assertRaises(errors.InvalidPDFError):
            parse_pdf(b"%PDF-1.4\n" + b"garbage " * 200)

    def test_password_protected_rc4(self):
        with self.assertRaises(errors.PasswordProtectedError):
            parse_pdf(encrypt(make_pdf([LONG]), "secret"))

    def test_password_protected_aes256(self):
        with self.assertRaises(errors.PasswordProtectedError):
            parse_pdf(encrypt(make_pdf([LONG]), "secret", algorithm="AES-256"))

    def test_encrypted_with_empty_user_password_still_opens(self):
        result = parse_pdf(encrypt(make_pdf([f"Open text. {LONG}"]), ""))
        self.assertIn("Open text.", result.pages[0].text)

    def test_too_many_pages(self):
        with self.assertRaises(errors.TooManyPagesError):
            parse_pdf(make_pdf([LONG] * 3), max_pages=2)

    def test_file_too_large(self):
        with self.assertRaises(errors.FileTooLargeError):
            parse_pdf(make_pdf([LONG]), max_bytes=10)

    def test_error_messages_are_user_safe(self):
        for exc in (errors.EmptyFileError(), errors.InvalidPDFError(),
                    errors.PasswordProtectedError(), errors.NoTextError()):
            self.assertTrue(exc.user_message)


if __name__ == "__main__":
    unittest.main()
