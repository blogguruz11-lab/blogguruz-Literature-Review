import unittest

from core.cache_keys import extraction_cache_key
from core.inputs import clean_research_question
from core.llm import to_llm_error


class RateLimitError(Exception): ...
class APIConnectionError(Exception): ...
class APITimeoutError(APIConnectionError): ...
class SomethingElse(Exception): ...


class CacheKeyTests(unittest.TestCase):
    BASE = dict(file_sha256="abc", model="m1", version="2.0", research_question="Q", max_chars=100)

    def key(self, **changes):
        return extraction_cache_key(**{**self.BASE, **changes})

    def test_same_inputs_same_key(self):
        self.assertEqual(self.key(), self.key())

    def test_each_setting_changes_the_key(self):
        for change in ({"file_sha256": "abd"}, {"model": "m2"}, {"version": "2.1"},
                       {"research_question": "Other"}, {"max_chars": 200}):
            self.assertNotEqual(self.key(), self.key(**change), change)

    def test_question_spacing_and_case_do_not_change_the_key(self):
        self.assertEqual(self.key(research_question="Does  sleep matter?"),
                         self.key(research_question=" does sleep matter? "))

    def test_no_question_differs_from_a_question(self):
        self.assertNotEqual(self.key(research_question=None), self.key())


class InputTests(unittest.TestCase):
    def test_empty_and_whitespace_questions_become_none(self):
        self.assertIsNone(clean_research_question(None))
        self.assertIsNone(clean_research_question("  \n\t "))

    def test_control_characters_are_removed(self):
        self.assertEqual(clean_research_question("a\x00b\x07c"), "a b c")


class ErrorMappingTests(unittest.TestCase):
    def test_known_errors_get_safe_messages(self):
        self.assertIn("rate limit", to_llm_error(RateLimitError("secret detail")).user_message)

    def test_most_specific_class_wins(self):
        self.assertIn("timed out", to_llm_error(APITimeoutError("x")).user_message)

    def test_unknown_errors_get_a_generic_message_without_details(self):
        message = to_llm_error(SomethingElse("paper text leaked here")).user_message
        self.assertNotIn("leaked", message)


if __name__ == "__main__":
    unittest.main()
