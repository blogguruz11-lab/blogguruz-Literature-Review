"""Builds small PDFs in memory for tests. Needs reportlab (see requirements-dev.txt)."""
import io

from pypdf import PdfReader, PdfWriter
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

LONG = ("This sentence is long enough to count as real page content for the tests, "
        "and it repeats so the page clears the minimum character threshold.")


def make_pdf(pages: list[str]) -> bytes:
    """One PDF page per string. An empty string gives a blank page."""
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    for text in pages:
        y = 800
        for line in text.split("\n"):
            if line:
                c.drawString(60, y, line)
                y -= 16
        c.showPage()
    c.save()
    return buf.getvalue()


def encrypt(data: bytes, user_password: str, algorithm: str | None = None) -> bytes:
    writer = PdfWriter(clone_from=PdfReader(io.BytesIO(data)))
    writer.encrypt(user_password, owner_password="owner-pw", algorithm=algorithm)
    out = io.BytesIO()
    writer.write(out)
    return out.getvalue()


def with_page_labels(data: bytes) -> bytes:
    """Pages 1-2 get roman numerals (i, ii); page 3 onwards restarts at 415."""
    writer = PdfWriter(clone_from=PdfReader(io.BytesIO(data)))
    writer.set_page_label(0, 1, style="/r")
    writer.set_page_label(2, len(writer.pages) - 1, style="/D", start=415)
    out = io.BytesIO()
    writer.write(out)
    return out.getvalue()
